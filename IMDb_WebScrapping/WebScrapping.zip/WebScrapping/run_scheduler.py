import schedule
import time
import main
import os

schedule.every().week.do(main.main())

filename = 'IMDb.csv'

while True:

    try:
        file = open(filename, 'r')
        
    except FileNotFoundError:
        pass

    else:
        file.close()
        os.remove(filename)

    schedule.run_pending()
    time.sleep(1)
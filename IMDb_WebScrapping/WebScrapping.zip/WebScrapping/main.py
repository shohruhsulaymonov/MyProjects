# from Packages.Convert import exchange_rates_to_usd
from selenium.webdriver import Chrome
from bs4 import BeautifulSoup
import requests
import pandas as pd
import re
import time

def get_movies_table():
    driver = Chrome()
    driver.get('https://www.imdb.com/chart/top/')
    time.sleep(5)
    soup = BeautifulSoup(driver.page_source, 'html.parser')
    driver.close()
    table = soup.find('ul', class_="ipc-metadata-list ipc-metadata-list--dividers-between sc-2b8fdbce-0 emPbxy compact-list-view ipc-metadata-list--base")


    movies_list = table.find_all('li', class_="ipc-metadata-list-summary-item")
    movie_links = ['https://www.imdb.com/' + movie.a['href'] for movie in movies_list]
    return movie_links

def get_movie_info(link):
    url = link

    response = requests.get(url, headers=({'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)', 'Accept-Language': 'US-en'})).text
    
    movie_page = BeautifulSoup(response, 'html.parser')


    title = movie_page.find('span', class_='hero__primary-text').text

    year = movie_page.find('ul', class_='ipc-inline-list ipc-inline-list--show-dividers sc-cb6a22b2-2 aFhKV baseAlt baseAlt').li.a.text

    r = movie_page.find('ul', class_='ipc-inline-list ipc-inline-list--show-dividers sc-cb6a22b2-2 aFhKV baseAlt baseAlt').li.next_sibling
    if r.a:
        rating = r.a.text
    else:
        rating = None

    runtime = movie_page.find(string='Runtime').next_element.text

    IMDb_rating = movie_page.find('span', class_='ipc-rating-star--rating').text

    votes = movie_page.find('span', class_='vote-count').text

    directors = movie_page.find(string=['Director', 'Directors']).next_element.ul
    directors = directors.find_all('li', class_='ipc-inline-list__item')
    director = [d.text for d in directors]

    movie_description = movie_page.find('p', class_='sc-bf30a0e-3 uWiw sc-bf30a0e-4 dKgygM').span.text

    top_stars = movie_page.find('div', class_='ipc-sub-grid ipc-sub-grid--page-span-2 ipc-sub-grid--wraps-at-above-l ipc-shoveler__grid').find_all('div', class_='sc-10bde568-7 bhMzVl')[:5]
    top_cast = [top_star.a.text for top_star in top_stars]
    
    budget = movie_page.find(string='Budget')
    if budget:
        budget = budget.next_element.span.text
        if str(budget) != 'nan':
            budget = str(budget).replace(',', '')
            budget = re.search(r".+\d+", budget)
            budget = budget.group()
            # currency = re.search(r'^([^\d\s,.]+)', budget).group()
            # amount = re.search(r"\d+", budget).group()
            # converted = int(amount) * exchange_rates_to_usd.get(currency)
            # budget = int(converted)
        else:
            budget = None
    else:
        budget = None

    gross_box_office = movie_page.find(string='Gross worldwide')
    if gross_box_office:
        gross_box_office = gross_box_office.next_element.span.text
        if str(gross_box_office) != 'nan':
            gross_box_office = str(gross_box_office).replace(',', '')
            gross_box_office = re.search(r"\d+", gross_box_office)
            gross_box_office = gross_box_office.group()
        else:
            gross_box_office = None
    else:
        gross_box_office = None

    countries = movie_page.find(string=['Country of origin', 'Countries of origin']).next_element.find_all('a')
    country = [cntry.text for cntry in countries]

    genre = movie_page.find_all('a', class_='ipc-chip ipc-chip--on-baseAlt')
    genres = [i.text for i in genre]


    final_result = {
        "Title":  title,
        "Release Year": year,
        "Director(s)": ';'.join(director),
        "IMDb Rating" : IMDb_rating,
        "Number of Votes": votes,
        "Genre(s)": ';'.join(genres),
        "Motion Picture Rating": rating,
        "Top Cast": ';'.join(top_cast),
        "Box Office": gross_box_office,
        "Budget": budget,
        "Country": ';'.join(country),
        "Runtime": runtime,
        "Description": movie_description
    }
    return final_result

df = pd.DataFrame(columns=['Title','Release Year','Director(s)','IMDb Rating','Number of Votes','Genre(s)','Motion Picture Rating','Top Cast','Box Office','Budget','Country','Runtime','Description'])

def main():
    links = get_movies_table()
    for movie_link in links:
        row = get_movie_info(movie_link)
        df.loc[len(df)] = row
        df.to_csv('IMDb.csv', index=False)


if __name__ == "__main__":
    main()